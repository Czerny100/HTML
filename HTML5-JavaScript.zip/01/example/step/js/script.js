<script language="JavaScript">
function maximize () {
    self.moveTo (0, 0);
    self.resizeTo (500, 300);
}
</script>