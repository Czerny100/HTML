var a = true;
var b = a;
a = false;
document.writeln(b);