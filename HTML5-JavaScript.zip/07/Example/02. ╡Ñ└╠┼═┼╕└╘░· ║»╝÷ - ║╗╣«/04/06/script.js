var a = [1,2,3,4];
var b = a;
a[0] = 100;
document.writeln(b);