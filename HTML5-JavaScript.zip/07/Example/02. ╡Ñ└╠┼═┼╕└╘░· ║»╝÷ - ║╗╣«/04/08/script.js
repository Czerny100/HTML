var a = function(name) {
	document.writeln(name + "님 안녕하세요");
}

var b = a;

b("홍길동");

/*
function greeting(name) {
	document.writeln(name + "님 안녕하세요");
}

var hi = greeting;

hi("홍길동");
*/