var i = 1;
var k = 1;

var j = ++i;
var y = k++;

document.writeln("j = ++i<br>");
document.writeln("j = " + j + "<br>");
document.writeln("i = " + i + "<br><br>");

document.writeln("y = k++<br>");
document.writeln("y = " + y + "<br>");
document.writeln("k = " + k + "<br>");