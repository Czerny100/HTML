var a = 123;
var b = "123";

if (a == b) {
	document.writeln("숫자 123과 문자열 \"123\"은 같다고 평가 됩니다");
} else {
	document.writeln("숫자 123과 문자열 \"123\"은 다르다고 평가 됩니다");
}

/*
var a = 123;
var b = "123";

if (a === b) {
	document.writeln("숫자 123과 문자열 \"123\"은 같다고 평가 됩니다");
} else {
	document.writeln("숫자 123과 문자열 \"123\"은 다르다고 평가 됩니다");
}
*/

/*
var a = 1;

if( a == true) { 
	document.writeln("동등 합니다.");
} else {
	document.writeln("동등하지 않습니다.");
}
*/

/*
var a = 1;

if( a === true) { 
	document.writeln("동등 합니다.");
} else {
	document.writeln("동등하지 않습니다.");
}
*/