var score = 97;
var subject = "English";

if ( score >= 90 && subject == "English") {
	document.writeln("영어 점수가 굉장히 높군요!");
}