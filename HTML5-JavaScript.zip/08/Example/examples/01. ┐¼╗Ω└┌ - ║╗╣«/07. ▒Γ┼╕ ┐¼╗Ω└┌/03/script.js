var a = [1,2,3,4,5];
var arrayType = typeof a;

document.writeln(arrayType);