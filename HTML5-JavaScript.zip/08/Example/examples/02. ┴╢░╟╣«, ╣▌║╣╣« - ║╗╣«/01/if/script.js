var eng = 83;

if (eng < 60) {
	alert("영어 점수는 \'가\' 입니다.");
} else if (eng >= 60 && eng < 70) {
	alert("영어 점수는 \'양\' 입니다.");
} else if (eng >= 70 && eng < 80) {
	alert("영어 점수는 \'미\' 입니다.");
} else if (eng >= 80 && eng < 90) {
	alert("영어 점수는 \'우\' 입니다.");
} else if (eng >= 90) {
	alert("영어 점수는 \'수\' 입니다.");
}
