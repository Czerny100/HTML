var total = 0;
for(var i = 0; i <= 10; i++) {
	total += i;
}
document.writeln("1에서 10까지의 합은 " + total + "입니다");


/*
var total = 0;
for(var i = 0; i <= 10; i+=2) {
	total += i;
}
document.writeln("1에서 10까지의 짝수 합은 " + total + "입니다");
*/