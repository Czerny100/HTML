var i = 11;
var total = 1;
do {
	total += i;
	i ++;
} while(i <= 10);

document.writeln(total);